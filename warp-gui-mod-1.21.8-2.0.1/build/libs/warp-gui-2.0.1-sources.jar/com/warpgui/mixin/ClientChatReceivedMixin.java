package com.warpgui.mixin;

import com.warpgui.client.ServerDetector;
import com.warpgui.client.WarpListManager;
import net.minecraft.class_2561;
import net.minecraft.class_634;
import net.minecraft.class_7439;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class ClientChatReceivedMixin {

    @Inject(method = "onGameMessage", at = @At("HEAD"), require = 0)
    private void warpgui$onGameMessage(class_7439 packet, CallbackInfo ci) {
        try {
            class_2561 message = packet.comp_763();
            if (message == null) return;
            String raw = message.getString();
            // ServerDetector 仅用于记录当前服务器信息，不影响 WarpListManager 状态
            ServerDetector.tryUpdateFromChat(raw);
            // 传给 warp 列表解析器
            WarpListManager.getInstance().onChatMessage(raw);
        } catch (Exception ignored) {}
    }
}
